<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

<link rel="stylesheet" type="text/css" href="content/css/style.css"/> 

<footer class="u-full-width">
        <div class="column">
            <div class="three columns">
                <a href="#"><i class="fas fa-home"></i></a>
            </div>

            <div class="three columns">
                <a href="#"><i class="fas fa-search"></i></a>
            </div>

            <div class="three columns">
                <a href="#"><i class="fas fa-plus"></i></a>
            </div>

            <div class="three columns">
                <a href="#"><i class="far fa-user"></i></a>
            </div>
        </div>
</footer>        

