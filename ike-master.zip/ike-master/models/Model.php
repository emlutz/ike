<?php
Class Model {
  var $con = null;
}
?>