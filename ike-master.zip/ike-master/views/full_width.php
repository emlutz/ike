<div class="full_width">
  <div class="card">
    <img class="card-img-top" src="assets/<?=$this->strImg?>" alt="thumbnail">
    <div class="details">
      <h4><?=$feed->strTitle?></h4>
      <p><?=$feed->strDescription?></p>
    </div>
  </div>
</div>
