<?php include ('content/header.php'); ?>
  <?php
  include('nav.php');
  ?>
  <main>
    <?=$this->mainBody?>
  </main>

  <?php include ('content/footer.php'); ?>