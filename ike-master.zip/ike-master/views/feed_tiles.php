<div class="container">
  <div class="feed">
    <?php
    foreach($this->memory as $mem){
      ?>
      <div class="card column">
        <img class="card-img-top" src="assets/<?=$mem["path"]?>" alt="thumbnail">
        <div class="details">
          <h4><?=$mem["title"]?></h4>
          <p><?=$mem["caption"]?></p>
        </div>
        <div class="actions">
          <a href=""></a>
          <a href=""></a>
          <img src="../assets/abc.jpg" width="100%">
        </div>
      </div>
      <?php
    }
    ?>
  </div>
</div>
